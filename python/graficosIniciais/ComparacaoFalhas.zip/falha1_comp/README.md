Nesta pasta encontram-se imagens comparativas entre a simulação com falha 1 e a simulação sem falhas, lado a lado, enquanto o comportamento da variável com a falha está no lado direito, o comportamento sem a falha está no lado esquerdo.

Os nomes dos arquivos foram definidos de modo a permitir uma rápida identificação. Além disso, optei por deixar todos os gráficos inclusos, apesar de que algumas variáveis não apresentaram alterações notáveis.

**Falha 1 = Alteração do tipo degrau na proporção de alimentação A/D (corrente 4), com a composição de B constante**

Aqui está uma lista de quais variáveis mais sofreram alterações
- Alimentacao_A_corrente_1
- Alimentacao_A_e_C_corrente_4
- Componente_F_Reator
- Componente_F_Purga
- Corrente_Purga
- Corrente_Vapor_do_stripper
- Temperatura_Stripper
- Manip_Valvula_Purga

Por fim, nota-se que o sistema de controle, para essa falha, conseguiu agir de modo a manter a planta em condições de operação normal para a maioria das variáveis.